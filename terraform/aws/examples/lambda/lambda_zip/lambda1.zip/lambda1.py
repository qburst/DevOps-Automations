import boto3
import botocore
import time

def disassociate_and_release_elastic_ips(ec2_client, vpc_id, region):
    addresses = ec2_client.describe_addresses(Filters=[{'Name': 'domain', 'Values': ['vpc']}])['Addresses']

    for address in addresses:
        association_id = address.get('AssociationId')
        allocation_id = address.get('AllocationId')
        
        if association_id:
            ec2_client.disassociate_address(AssociationId=association_id)
        elif allocation_id:
            ec2_client.release_address(AllocationId=allocation_id)
        
        print(f"Disassociated/Released Elastic IP: {address['PublicIp']} in region {region}")

def detach_and_delete_igw(ec2_client, vpc_id, region):
    igws = ec2_client.describe_internet_gateways(Filters=[{'Name': 'attachment.vpc-id', 'Values': [vpc_id]}])['InternetGateways']
    
    for igw in igws:
        igw_id = igw['InternetGatewayId']
        ec2_client.detach_internet_gateway(InternetGatewayId=igw_id, VpcId=vpc_id)

        try:
            ec2_client.delete_internet_gateway(InternetGatewayId=igw_id)
            print(f"Deleted Internet Gateway {igw_id} in region {region}")
        except Exception as e:
            print(f"Error deleting Internet Gateway {igw_id} in region {region}: {str(e)}")

def detach_and_delete_route_tables(ec2_client, vpc_id, region):
    route_tables = ec2_client.describe_route_tables(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])['RouteTables']
    
    for route_table in route_tables:
        for association in route_table['Associations']:
            if not association.get('Main', False):
                ec2_client.disassociate_route_table(AssociationId=association['RouteTableAssociationId'])

                try:
                    ec2_client.delete_route_table(RouteTableId=route_table['RouteTableId'])
                    print(f"Deleted Route Table {route_table['RouteTableId']} in region {region}")
                except Exception as e:
                    print(f"Error deleting Route Table {route_table['RouteTableId']} in region {region}: {str(e)}")

def detach_and_delete_enis(ec2_client, vpc_id, region):
    enis = ec2_client.describe_network_interfaces(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])['NetworkInterfaces']
    
    for eni in enis:
        eni_id = eni['NetworkInterfaceId']
        
        if eni['Attachment']:
            ec2_client.detach_network_interface(AttachmentId=eni['Attachment']['AttachmentId'], Force=True)

        try:
            ec2_client.delete_network_interface(NetworkInterfaceId=eni_id)
            print(f"Deleted Network Interface {eni_id} in region {region}")
        except Exception as e:
            print(f"Error deleting Network Interface {eni_id} in region {region}: {str(e)}")

def delete_subnets(ec2_client, vpc_id, region):
    subnets = ec2_client.describe_subnets(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])['Subnets']

    for subnet in subnets:
        subnet_id = subnet['SubnetId']

        try:
            ec2_client.delete_subnet(SubnetId=subnet_id)
            print(f"Deleted Subnet {subnet_id} in region {region}")
        except Exception as e:
            print(f"Error deleting Subnet {subnet_id} in region {region}: {str(e)}")

# def delete_security_groups(ec2_client, vpc_id, region):
#     security_groups = ec2_client.describe_security_groups(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])['SecurityGroups']

#     for security_group in security_groups:
#         group_id = security_group['GroupId']
        
#         try:
#             ec2_client.delete_security_group(GroupId=group_id)
#             print(f"Deleted Security Group {group_id} in region {region}")
#         except Exception as e:
#             print(f"Error deleting Security Group {group_id} in region {region}: {str(e)}")


def delete_default_vpc(ec2_client, vpc_id, region):
    try:
        ec2_client.delete_vpc(VpcId=vpc_id)
    
        print(f"Deleted default VPC {vpc_id} in region {region}")
    except botocore.exceptions.ClientError as e:
        if 'DependencyViolation' in str(e):
            print(f"Attempting to forcefully delete default VPC {vpc_id} in region {region}")
            while True:
                try:
                    ec2_client.delete_vpc(VpcId=vpc_id)
                    print(f"Forcefully deleted default VPC {vpc_id} in region {region}")
                    break
                except botocore.exceptions.ClientError as e:
                    print(f"Retry: Error deleting default VPC {vpc_id} in region {region}: {str(e)}")
                    time.sleep(5)
        else:
            print(f"Error deleting default VPC {vpc_id} in region {region}: {str(e)}")

def delete_default_vpcs(ec2_client, region):
    vpcs = ec2_client.describe_vpcs(Filters=[{'Name': 'isDefault', 'Values': ['true']}])['Vpcs']
    
    for vpc in vpcs:
        vpc_id = vpc['VpcId']
        
        disassociate_and_release_elastic_ips(ec2_client, vpc_id, region)
        detach_and_delete_igw(ec2_client, vpc_id, region)
        detach_and_delete_route_tables(ec2_client, vpc_id, region)
        detach_and_delete_enis(ec2_client, vpc_id, region)
        delete_subnets(ec2_client, vpc_id, region)
        # delete_security_groups(ec2_client, vpc_id, region)
        delete_default_vpc(ec2_client, vpc_id, region)

def lambda_handler(event, context):
    regions = event['regions']
    print(regions)

    for region in regions:
        try:
            ec2_client = boto3.client('ec2', region_name=region)
            
            delete_default_vpcs(ec2_client, region)
            
            print(f"Successfully deleted resources in region: {region}")
            
        except Exception as e:
            print(f"Error processing region {region}: {str(e)}")

